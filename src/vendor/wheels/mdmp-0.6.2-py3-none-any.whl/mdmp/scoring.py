"""
Scoring functions for MDM structure learning.

This module implements discount factor selection and log predictive likelihood
computation for MDM model scoring.
"""

from typing import Any, Dict, Optional, Tuple

import numpy as np
from scipy.optimize import minimize_scalar

from ._node_dispatch import evaluate_lpl
from .constants import DEFAULT_NBF
from .dlm import dlm_filter
from .utils import build_design_matrix, extract_target_series, get_default_delta


def select_discount_factors(
    data: np.ndarray,
    adj_mat: np.ndarray,
    nbf: int = DEFAULT_NBF,
    delta: Optional[np.ndarray] = None,
    n_jobs: Optional[int] = None,
    verbose: bool = False
) -> Dict[str, Any]:
    """
    Select discount factors that maximize log predictive likelihood for each node.

    Parameters
    ----------
    data : np.ndarray
        Time series data (T x N).
    adj_mat : np.ndarray
        Adjacency matrix (N x N).
    nbf : int, optional
        Burn-in time point. Default is 15.
    delta : np.ndarray, optional
        Sequence of discount factors. Default is np.arange(0.5, 1.01, 0.01).
    n_jobs : int, optional
        Number of parallel jobs. If None or 1, uses serial processing.
        If -1, uses all available CPU cores. If > 1, uses that many workers.
        Default is None (serial processing).
    verbose : bool, optional
        Whether to show progress bars. Default is False.

    Returns
    -------
    dict
        Dictionary containing:
        - lpldet : Log predictive likelihoods for each delta and node (nd, N)
        - DF_hat : Selected discount factors for each node (N,)

    Raises
    ------
    ValueError
        If data and adj_mat dimensions are incompatible.

    Examples
    --------
    >>> import numpy as np
    >>> from mdmp.scoring import select_discount_factors
    >>> data = np.random.randn(100, 3)
    >>> adj_mat = np.zeros((3, 3))
    >>> adj_mat[0, 1] = 1
    >>> result = select_discount_factors(data, adj_mat)
    >>> print(result['DF_hat'])
    """
    if delta is None:
        delta = get_default_delta()

    nd = len(delta)
    Nn = data.shape[1]
    lpldet = np.zeros((nd, Nn))

    # Pre-compute design matrices and target series for each node
    # (they don't depend on delta, so we can cache them)
    design_matrices = {}
    target_series = {}
    for i in range(Nn):
        design_matrices[i], _ = build_design_matrix(data, adj_mat, i)
        target_series[i] = extract_target_series(data, i)

    # Evaluate log predictive likelihood for each delta and node
    lpldet = evaluate_lpl(
        delta=delta,
        design_matrices=design_matrices,
        target_series=target_series,
        nbf=nbf,
        n_jobs=n_jobs,
        verbose=verbose,
    )

    # Select best delta for each node (handling NaN values)
    DF_hat = _select_best_deltas(lpldet, delta, Nn)

    return {
        'lpldet': lpldet,
        'DF_hat': DF_hat
    }


def _select_best_deltas(
    lpldet: np.ndarray,
    delta: np.ndarray,
    num_nodes: int,
    default_delta: float = 0.9
) -> np.ndarray:
    """
    Select the best discount factor for each node based on log predictive likelihood.

    Parameters
    ----------
    lpldet : np.ndarray
        Log predictive likelihoods (nd, N).
    delta : np.ndarray
        Array of discount factors.
    num_nodes : int
        Number of nodes.
    default_delta : float, optional
        Default discount factor if all values are NaN. Default is 0.9.

    Returns
    -------
    np.ndarray
        Selected discount factors for each node (N,).
    """
    DF_hat = np.zeros(num_nodes)
    for i in range(num_nodes):
        valid_indices = ~np.isnan(lpldet[:, i])
        if np.any(valid_indices):
            max_idx = np.nanargmax(lpldet[:, i])
            DF_hat[i] = delta[max_idx]
        else:
            DF_hat[i] = default_delta
    return DF_hat


def compute_logpl(
    data: np.ndarray,
    adj_mat: np.ndarray,
    delta: float,
    node_idx: int,
    nbf: int = DEFAULT_NBF
) -> float:
    """
    Compute negative log predictive likelihood for a given node and discount factor.

    Used in optimization for structure learning.

    Parameters
    ----------
    data : np.ndarray
        Time series data (T x N).
    adj_mat : np.ndarray
        Adjacency matrix (N x N).
    delta : float
        Discount factor (must be between 0 and 1).
    node_idx : int
        Index of target node.
    nbf : int, optional
        Burn-in time point. Default is 15.

    Returns
    -------
    float
        Negative log predictive likelihood.

    Raises
    ------
    ValueError
        If node_idx is out of bounds or adj_mat dimensions don't match data.

    Examples
    --------
    >>> import numpy as np
    >>> from mdmp.scoring import compute_logpl
    >>> data = np.random.randn(100, 3)
    >>> adj_mat = np.zeros((3, 3))
    >>> logpl = compute_logpl(data, adj_mat, delta=0.9, node_idx=0)
    >>> print(logpl)
    """
    if delta > 1 or delta < 0:
        return np.inf

    # Validate inputs
    if node_idx < 0 or node_idx >= data.shape[1]:
        raise ValueError(
            f"node_idx ({node_idx}) must be between 0 and {data.shape[1] - 1}"
        )

    if adj_mat.shape[0] != data.shape[1] or adj_mat.shape[1] != data.shape[1]:
        raise ValueError(
            f"adj_mat shape {adj_mat.shape} does not match data shape {data.shape}"
        )

    # Build design matrix and extract target series
    Ft, _ = build_design_matrix(data, adj_mat, node_idx)
    Yt = extract_target_series(data, node_idx)

    # Run DLM filter and compute log predictive likelihood
    result = dlm_filter(Yt, Ft.T, delta=delta)
    lpldet = np.sum(result['lpl'][nbf:])

    return -lpldet


# Alias: compute_local_score(data, adj_mat, node_idx, delta, nbf) delegates to compute_logpl.
# Note: argument order differs — compute_logpl takes (data, adj_mat, delta, node_idx, nbf).
def compute_local_score(
    data: np.ndarray,
    adj_mat: np.ndarray,
    node_idx: int,
    delta: float,
    nbf: int = DEFAULT_NBF,
) -> float:
    """Negative log predictive likelihood for one node. Alias of compute_logpl."""
    return compute_logpl(data, adj_mat, delta, node_idx, nbf)


def optimize_local_score(
    data: np.ndarray,
    adj_mat: np.ndarray,
    node_idx: int,
    nbf: int = DEFAULT_NBF,
    bounds: Tuple[float, float] = (0.0, 1.0),
    method: str = "bounded"
) -> Tuple[float, float]:
    """
    Optimize the discount factor (delta) to maximize log predictive likelihood for a node.

    This function performs continuous optimization of the discount factor for a single
    node given its parent structure. It can be used by any structure learning algorithm
    that needs to find the optimal delta for a node.

    Parameters
    ----------
    data : np.ndarray
        Time series data (T x N).
    adj_mat : np.ndarray
        Adjacency matrix (N x N).
    node_idx : int
        Index of target node.
    nbf : int, optional
        Burn-in time point. Default is 15.
    bounds : tuple of float, optional
        Bounds for delta optimization. Default is (0.0, 1.0).
    method : str, optional
        Optimization method for minimize_scalar. Default is "bounded".

    Returns
    -------
    tuple of float
        Tuple containing (optimized_score, optimal_delta).
        The optimized_score is the negated log predictive likelihood (to be maximized).
        If optimization fails, returns (-np.inf, np.nan).

    Raises
    ------
    ValueError
        If node_idx is out of bounds or adj_mat dimensions don't match data.

    Examples
    --------
    >>> import numpy as np
    >>> from mdmp.scoring import optimize_local_score
    >>> data = np.random.randn(100, 3)
    >>> adj_mat = np.zeros((3, 3))
    >>> adj_mat[0, 1] = 1  # Node 0 is parent of node 1
    >>> score, delta = optimize_local_score(data, adj_mat, node_idx=1)
    >>> print(f"Optimal score: {score}, Optimal delta: {delta}")
    """
    def objective(delta_value: float) -> float:
        """Objective function for optimization: minimize negative logpl."""
        return compute_logpl(data, adj_mat, delta_value, node_idx, nbf)

    result = minimize_scalar(
        objective,
        bounds=bounds,
        method=method
    )

    if not result.success or not np.isfinite(result.fun):
        return (-np.inf, np.nan)

    # Return negated value (since we're minimizing negative logpl, we want to maximize)
    # result.fun is the minimum negative logpl, so -result.fun is the maximum logpl
    return (-result.fun, result.x)

